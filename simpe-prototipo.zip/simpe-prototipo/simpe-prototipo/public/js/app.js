const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const lsGet=k=>{try{return localStorage.getItem(k)}catch(e){return null}},lsSet=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
document.documentElement.dataset.theme=lsGet('simpe-theme')||'dark';
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const br=d=>d?String(d).split('-').reverse().join('/'):'';
const num=(v,d=1)=>typeof v==='number'?v.toFixed(d).replace('.',','):'—';
async function api(m,u,b){
  let r;try{r=await fetch(u,{method:m,cache:'no-store',headers:b?{'Content-Type':'application/json'}:{},body:b?JSON.stringify(b):undefined})}catch(e){throw new Error('Sem conexão com o servidor')}
  let j=null;try{j=await r.json()}catch(e){}
  if(r.status===401&&!/login|cadastro/.test(location.pathname)){location.href='login.html';throw new Error('Sessão expirada')}
  if(!r.ok)throw new Error((j&&j.erro)||'Erro '+r.status);
  return j}
function toast(m){let t=$('#toast');if(!t){t=document.createElement('div');t.id='toast';document.body.append(t)}t.textContent=m;t.style.display='block';clearTimeout(t._t);t._t=setTimeout(()=>t.style.display='none',2600)}
const CH=[];
function chart(cv,data,o={}){const i=CH.findIndex(a=>a[0]===cv);if(i>=0)CH[i]=[cv,data,o];else CH.push([cv,data,o]);draw(cv,data,o)}
function draw(cv,data,o){const c=getComputedStyle(document.documentElement),x=cv.getContext('2d'),r=devicePixelRatio||1,w=cv.clientWidth,h=cv.clientHeight;if(!w)return;cv.width=w*r;cv.height=h*r;x.scale(r,r);
const mn=o.min??(data.length?Math.min(...data):0),mx=o.max??(data.length?Math.max(...data):1),p=30,X=i=>p+i*(w-p-6)/Math.max(data.length-1,1),Y=v=>h-14-(v-mn)/(mx-mn||1)*(h-26);
x.font='10px Segoe UI';x.lineWidth=1;
for(let i=0;i<=3;i++){const v=mn+(mx-mn)*i/3,y=Y(v);x.strokeStyle=c.getPropertyValue('--bd');x.beginPath();x.moveTo(p,y);x.lineTo(w,y);x.stroke();x.fillStyle=c.getPropertyValue('--mu');x.fillText(Math.round(v),0,y+3)}
if(o.lim&&o.lim>=mn&&o.lim<=mx){x.strokeStyle=c.getPropertyValue('--er');x.setLineDash([5,4]);x.beginPath();x.moveTo(p,Y(o.lim));x.lineTo(w,Y(o.lim));x.stroke();x.setLineDash([])}
if(data.length<2)return;
x.strokeStyle=c.getPropertyValue('--ac');x.lineWidth=1.8;x.beginPath();data.forEach((v,i)=>i?x.lineTo(X(i),Y(v)):x.moveTo(X(i),Y(v)));x.stroke()}
addEventListener('resize',()=>CH.forEach(a=>draw(...a)));
function setTheme(){const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;lsSet('simpe-theme',t);CH.forEach(a=>draw(...a));$$('[data-tg]').forEach(b=>b.textContent=t==='dark'?'Tema claro':'Tema escuro')}
function bindTheme(){$$('[data-tg]').forEach(b=>{b.textContent=document.documentElement.dataset.theme==='dark'?'Tema claro':'Tema escuro';b.onclick=setTheme})}
document.addEventListener('DOMContentLoaded',()=>{bindTheme();
document.addEventListener('click',e=>{const b=e.target.closest('[data-m]');$$('.menu').forEach(m=>{if(!b||m.id!==b.dataset.m)m.hidden=true});if(b){const m=$('#'+b.dataset.m);m.hidden=!m.hidden}})});

let ME=null;
/* Barra superior com usuário real. Uso: topbar('cat').then(me=>{...}) */
async function topbar(on){
  const [me,nt]=await Promise.all([api('GET','/api/me'),api('GET','/api/notificacoes').catch(()=>[])]);ME=me;
  const adm=me.perfil==='Administrador',ini=me.nome.split(/\s+/).filter(Boolean).slice(0,2).map(s=>s[0]).join('').toUpperCase();
  document.body.insertAdjacentHTML('afterbegin',`<header class="top"><a class="logo" href="catalogo.html"><svg viewBox="0 0 26 26"><rect width="26" height="26" fill="var(--ac)"/><path d="M15 3 7 15h5l-1 8 8-12h-5z" fill="var(--acx)"/></svg>SIMPE</a>
<nav><a class="nl ${on=='cat'?'on':''}" href="catalogo.html">Catálogo de Painéis</a>${adm?`<a class="nl ${on=='adm'?'on':''}" href="admin.html">Administração</a>`:''}</nav>
<button class="ib hide" data-tg></button>
<div class="wrap"><button class="ib" data-m="mn">Notificações${nt.length?`<span class="bd">${nt.length}</span>`:''}</button><div class="menu" id="mn" hidden>${nt.length?nt.map(n=>`<${n.link?`a href="${esc(n.link)}"`:'div'}><b>${esc(n.titulo)}</b><br><span class="mu sm">${esc(n.texto)}${n.quando?' · '+esc(n.quando):''}</span></${n.link?'a':'div'}>`).join(''):'<div class="mu sm">Nenhuma notificação.</div>'}</div></div>
<div class="wrap"><button class="ib" data-m="ms">Configurações</button><div class="menu" id="ms" hidden><div class="mu sm">Tema</div><button data-tg></button></div></div>
<div class="wrap"><button class="ib usr" data-m="mu"><span class="av">${esc(ini)}</span><span class="hide"><b>${esc(me.nome)}</b><br><span class="mu sm">${esc(me.departamento)} · ${esc(me.perfil)}</span></span></button><div class="menu" id="mu" hidden><button id="bp">Meu perfil</button><button id="bs">Alterar senha</button><button id="bx">Sair</button></div></div></header>
<dialog id="dp"><form id="fp"><h1>Meu perfil</h1><p class="mu sm">${esc(me.email)} · ID ${esc(me.idFuncionario)}</p><label for="pn">Nome</label><input id="pn" required value="${esc(me.nome)}"><label for="pd">Departamento</label><input id="pd" required value="${esc(me.departamento)}"><p class="msg" id="pg"></p><div class="row" style="justify-content:flex-end;margin-top:14px"><button type="button" class="btn" data-x="dp">Cancelar</button><button class="btn pr">Salvar</button></div></form></dialog>
<dialog id="ds"><form id="fs2"><h1>Alterar senha</h1><label for="sa">Senha atual</label><input id="sa" type="password" required><label for="sn">Nova senha</label><input id="sn" type="password" required minlength="8"><label for="sc">Confirmar nova senha</label><input id="sc" type="password" required><p class="msg" id="sg"></p><div class="row" style="justify-content:flex-end;margin-top:14px"><button type="button" class="btn" data-x="ds">Cancelar</button><button class="btn pr">Salvar</button></div></form></dialog>`);
  bindTheme();
  const msg=(id,t,ok)=>{const g=$('#'+id);g.className='msg '+(ok?'ok':'er');g.textContent=t};
  $$('[data-x]').forEach(b=>b.onclick=()=>$('#'+b.dataset.x).close());
  $('#bp').onclick=()=>{$('#pg').textContent='';$('#dp').showModal()};
  $('#bs').onclick=()=>{$('#fs2').reset();$('#sg').textContent='';$('#ds').showModal()};
  $('#bx').onclick=async()=>{try{await api('POST','/api/logout')}catch(e){}location.href='login.html'};
  $('#fp').onsubmit=async e=>{e.preventDefault();try{await api('PUT','/api/me',{nome:$('#pn').value,departamento:$('#pd').value});location.reload()}catch(x){msg('pg',x.message)}};
  $('#fs2').onsubmit=async e=>{e.preventDefault();if($('#sn').value!==$('#sc').value)return msg('sg','As senhas não coincidem.');
    try{await api('POST','/api/senha',{atual:$('#sa').value,nova:$('#sn').value});$('#ds').close();toast('Senha alterada')}catch(x){msg('sg',x.message)}};
  return me}
