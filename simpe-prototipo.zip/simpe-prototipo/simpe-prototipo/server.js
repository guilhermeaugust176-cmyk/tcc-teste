'use strict';
/*
 * SIMPE - Sistema Inteligente de Monitoramento de Painéis Elétricos
 * Servidor Express com persistência em arquivos .json (sem banco externo).
 *
 * Arquivos gerados (em SIMPE_DATA, por padrão a pasta do projeto):
 *   usuarios.json, historico.json, estado.json, paineis.json, solicitacoes.json,
 *   alarmes.json, leituras.json, sessoes.json, config.json
 *
 * Compatibilidade ESP32 (NÃO ALTERAR o formato):
 *   GET  /api/estado      -> {"ventoinha1":bool,"ventoinha2":bool}  (sem login)
 *   POST /api/ventoinhas  -> { ventoinha1?:bool, ventoinha2?:bool }
 */
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';
const DIR = process.env.SIMPE_DATA || __dirname;
const FUSO = process.env.SIMPE_TZ || 'America/Sao_Paulo';
const SESSAO_MS = 12 * 3600 * 1000;
const ONLINE_MS = 30 * 1000;   // painel "online" se houve leitura recente
const ESP32_MS = 5 * 1000;     // ESP32 "conectado" se consultou /api/estado recentemente
const PAGINAS_PUBLICAS = new Set(['/login.html', '/cadastro.html']);
const SENSORES = { corrente: ['Corrente', 'A'], temperatura: ['Temperatura', '°C'], umidade: ['Umidade', '%'], vibracao: ['Vibração', 'mm/s'] };

fs.mkdirSync(DIR, { recursive: true });

// ───────────── Persistência ─────────────
const arq = n => path.join(DIR, n + '.json');
function ler(nome, padrao) {
  try { return JSON.parse(fs.readFileSync(arq(nome), 'utf8')); } catch (e) { return padrao; }
}
function gravar(nome, dados) {               // escrita atômica (temp + rename)
  const f = arq(nome), tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(dados, null, 2));
  fs.renameSync(tmp, f);
}
const adiados = {};
function gravarDepois(nome, obter, ms = 5000) {   // para dados de alta frequência (leituras)
  if (adiados[nome]) return;
  adiados[nome] = setTimeout(() => { delete adiados[nome]; gravar(nome, obter()); }, ms);
}

const PADRAO_LIMITES = { corrente: 25, temperatura: 60, umidade: 80, vibracao: 4 };
const PAINEIS_INICIAIS = [
  ['QD-001', 'Quadro Geral de Baixa Tensão', 'Subestação A', 'Quadro principal de distribuição em 380 V, responsável pela alimentação das linhas de produção 1 e 2.'],
  ['QD-002', 'CCM Linha 1', 'Galpão de Produção', 'Centro de controle de motores da Linha 1, com partidas e proteção de 12 motores.'],
  ['QD-003', 'CCM Linha 2', 'Galpão de Produção', 'Centro de controle de motores da Linha 2, com inversores de frequência.'],
  ['QD-004', 'Quadro de Iluminação', 'Almoxarifado', 'Distribuição da iluminação e tomadas do almoxarifado.'],
  ['QD-005', 'Painel de Bombas', 'Casa de Bombas', 'Comando das bombas de recalque e de incêndio.'],
  ['QD-006', 'Banco de Capacitores', 'Subestação A', 'Correção de fator de potência da subestação.'],
  ['QD-007', 'QDF Escritórios', 'Administração', 'Quadro de distribuição do prédio administrativo.'],
  ['QD-008', 'Painel do Gerador', 'Casa de Força', 'Transferência automática e supervisão do grupo gerador.']
].map(a => ({ id: a[0], nome: a[1], setor: a[2], descricao: a[3], limites: { ...PADRAO_LIMITES } }));

const salvoEstado = ler('estado', {});
let estado = { ventoinha1: salvoEstado.ventoinha1 === true, ventoinha2: salvoEstado.ventoinha2 === true };
let usuarios = ler('usuarios', []);
let historico = ler('historico', []);
let paineis = ler('paineis', null) || PAINEIS_INICIAIS;
let solicitacoes = ler('solicitacoes', []);
let alarmes = ler('alarmes', []);
let leituras = ler('leituras', {});
let sessoes = ler('sessoes', {});
let config = ler('config', null);
usuarios.forEach(u => { u.paineis = u.paineis || []; u.favoritos = u.favoritos || []; u.recentes = u.recentes || []; });
if (!config) { config = { tokenDispositivo: crypto.randomBytes(24).toString('hex') }; gravar('config', config); }
const TOKEN_DISPOSITIVO = process.env.SIMPE_TOKEN || config.tokenDispositivo;
gravar('estado', estado);
gravar('paineis', paineis);

// ───────────── Utilidades ─────────────
const fmtData = new Intl.DateTimeFormat('sv-SE', { timeZone: FUSO, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' });
function agora() {
  const d = new Date(), s = fmtData.format(d);       // "2026-11-17 20:41:00"
  return { ts: d.toISOString(), data: s.slice(0, 10), hora: s.slice(11, 19) };
}
const uuid = () => crypto.randomUUID();
const txt = (v, max = 120) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const erro = (res, codigo, msg) => res.status(codigo).json({ erro: msg });
const isAdmin = u => u.perfil === 'Administrador';
const podeControlar = u => isAdmin(u) || u.controle === true;
const temAcesso = (u, id) => isAdmin(u) || u.paineis.includes(id);

function registrar(tipo, acao, usuario, detalhe) {
  historico.push({ id: uuid(), ...agora(), tipo, acao, usuario: usuario ? usuario.nome : 'Sistema', usuarioId: usuario && usuario.id ? usuario.id : null, detalhe: detalhe || '' });
  if (historico.length > 10000) historico = historico.slice(-10000);
  gravar('historico', historico);
}

const hashSenha = (s, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, hash: crypto.scryptSync(s, salt, 64).toString('hex') });
const SENHA_FALSA = hashSenha('x');
function confere(s, reg) {
  const h = crypto.scryptSync(s, reg.salt, 64), b = Buffer.from(reg.hash, 'hex');
  return b.length === h.length && crypto.timingSafeEqual(h, b);
}
function tokenValido(t) {
  const a = Buffer.from(String(t || '')), b = Buffer.from(TOKEN_DISPOSITIVO);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const pub = u => ({
  id: u.id, nome: u.nome, email: u.email, idFuncionario: u.idFuncionario, departamento: u.departamento,
  perfil: u.perfil, ativo: u.ativo !== false, controle: u.controle === true, podeControlar: podeControlar(u),
  paineis: u.paineis, criadoEm: u.criadoEm
});

// ───────────── Sessão (cookie HttpOnly) ─────────────
const hashToken = t => crypto.createHash('sha256').update(t).digest('hex');
function lerCookies(req) {
  const o = {};
  (req.headers.cookie || '').split(';').forEach(c => {
    const i = c.indexOf('=');
    if (i > 0) { try { o[c.slice(0, i).trim()] = decodeURIComponent(c.slice(i + 1).trim()); } catch (e) { /* ignora */ } }
  });
  return o;
}
function abrirSessao(res, u) {
  const t = crypto.randomBytes(32).toString('hex');
  sessoes[hashToken(t)] = { uid: u.id, exp: Date.now() + SESSAO_MS };
  gravar('sessoes', sessoes);
  res.cookie('simpe_sid', t, { httpOnly: true, sameSite: 'lax', maxAge: SESSAO_MS, path: '/' });
}
function encerrarSessoes(uid) {
  Object.keys(sessoes).forEach(k => { if (sessoes[k].uid === uid) delete sessoes[k]; });
  gravar('sessoes', sessoes);
}
setInterval(() => {
  let mudou = false;
  Object.keys(sessoes).forEach(k => { if (sessoes[k].exp < Date.now()) { delete sessoes[k]; mudou = true; } });
  if (mudou) gravar('sessoes', sessoes);
}, 3600 * 1000).unref();

// ───────────── App e middlewares ─────────────
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY' });
  const t = lerCookies(req).simpe_sid;
  const s = t && sessoes[hashToken(t)];
  if (s && s.exp > Date.now()) {
    const u = usuarios.find(x => x.id === s.uid && x.ativo !== false);
    if (u) { req.user = u; req.sidKey = hashToken(t); }
  }
  next();
});

const exigeLogin = (req, res, next) => (req.user ? next() : erro(res, 401, 'Faça login para continuar'));
const exigeAdmin = (req, res, next) => (!req.user ? erro(res, 401, 'Faça login para continuar') : isAdmin(req.user) ? next() : erro(res, 403, 'Acesso restrito a Administradores'));

app.get('/', (req, res) => res.redirect(req.user ? '/catalogo.html' : '/login.html'));

// URLs sem extensão (/login, /painel?id=QD-001...) redirecionam para o .html correspondente
app.use((req, res, next) => {
  const m = /^\/(login|cadastro|catalogo|painel|admin)\/?$/i.exec(req.path);
  if (!m || (req.method !== 'GET' && req.method !== 'HEAD')) return next();
  const i = req.originalUrl.indexOf('?');
  res.redirect('/' + m[1].toLowerCase() + '.html' + (i >= 0 ? req.originalUrl.slice(i) : ''));
});

// Bloqueio das páginas internas sem login
app.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next();
  let p;
  try { p = decodeURIComponent(req.path).toLowerCase(); } catch (e) { return res.status(400).end(); }
  if (!p.endsWith('.html')) return next();
  if (PAGINAS_PUBLICAS.has(p)) return req.user ? res.redirect('/catalogo.html') : next();
  if (!req.user) return res.redirect('/login.html');
  if (p === '/admin.html' && !isAdmin(req.user)) return res.redirect('/catalogo.html');
  res.set('Cache-Control', 'no-store');
  next();
});
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// ───────────── Rotas do ESP32 (compatibilidade) ─────────────
let ultimoContato = 0;
const hardware = () => ({
  conectado: Date.now() - ultimoContato < ESP32_MS,
  ultimoContato: ultimoContato ? new Date(ultimoContato).toISOString() : null,
  mensagem: Date.now() - ultimoContato < ESP32_MS ? 'Hardware: ESP32 conectado' : 'Hardware: Aguardando ESP32'
});

// Estado atual. Consultado pelo ESP32 (sem cookie) — o site usa /api/status.
app.get('/api/estado', (req, res) => {
  if (!req.user) ultimoContato = Date.now();
  res.set('Cache-Control', 'no-store');
  res.json({ ventoinha1: estado.ventoinha1, ventoinha2: estado.ventoinha2 });
});

// Liga/desliga uma ou as duas ventoinhas. Exige login com permissão de controle (ou token de dispositivo).
app.post('/api/ventoinhas', (req, res) => {
  const dispositivo = tokenValido(req.get('x-device-token'));
  if (!req.user && !dispositivo) return erro(res, 401, 'Faça login para enviar comandos');
  if (req.user && !podeControlar(req.user)) return erro(res, 403, 'Seu perfil não tem permissão de controle');
  const body = req.body || {}, novos = {};
  for (const chave of ['ventoinha1', 'ventoinha2']) {
    if (chave in body) {
      if (typeof body[chave] !== 'boolean') return erro(res, 400, `"${chave}" deve ser true ou false`);
      novos[chave] = body[chave];
    }
  }
  if (!Object.keys(novos).length) return erro(res, 400, 'Envie "ventoinha1" e/ou "ventoinha2" (booleano)');
  const ator = req.user || { nome: 'Dispositivo (token)', id: null };
  let alterou = false;
  for (const chave of Object.keys(novos)) {
    if (estado[chave] === novos[chave]) continue;
    estado[chave] = novos[chave];
    alterou = true;
    registrar('comando', `Ventoinha ${chave.slice(-1)} ${novos[chave] ? 'ligada' : 'desligada'}`, ator, hardware().mensagem);
  }
  if (alterou) gravar('estado', estado);
  res.json({ ventoinha1: estado.ventoinha1, ventoinha2: estado.ventoinha2 });
});

app.get('/api/status', exigeLogin, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ventoinha1: estado.ventoinha1, ventoinha2: estado.ventoinha2, hardware: hardware() });
});

// ───────────── Autenticação ─────────────
app.post('/api/cadastro', (req, res) => {
  const b = req.body || {};
  const nome = txt(b.nome), email = txt(b.email).toLowerCase(), idf = txt(b.idFuncionario, 40), dep = txt(b.departamento), senha = typeof b.senha === 'string' ? b.senha : '';
  if (!nome || !email || !idf || !dep) return erro(res, 400, 'Preencha todos os campos');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return erro(res, 400, 'E-mail inválido');
  if (senha.length < 8) return erro(res, 400, 'A senha deve ter ao menos 8 caracteres');
  if (usuarios.some(u => u.email === email)) return erro(res, 409, 'E-mail já cadastrado');
  if (usuarios.some(u => u.idFuncionario.toLowerCase() === idf.toLowerCase())) return erro(res, 409, 'ID de funcionário já cadastrado');
  const primeiro = usuarios.length === 0;   // o primeiro cadastro vira Administrador
  const u = { id: uuid(), nome, email, idFuncionario: idf, departamento: dep, perfil: primeiro ? 'Administrador' : 'Operador', ativo: true, senha: hashSenha(senha), paineis: [], controle: false, favoritos: [], recentes: [], criadoEm: agora().ts };
  usuarios.push(u);
  gravar('usuarios', usuarios);
  let solicitou = false;
  if (b.solicitarAdmin === true && !primeiro) {
    solicitacoes.push({ id: uuid(), usuarioId: u.id, usuarioNome: u.nome, tipo: 'promocao', painelId: null, titulo: 'Promoção a Administrador', justificativa: 'Solicitado no cadastro', status: 'Pendente', criadoEm: agora() });
    gravar('solicitacoes', solicitacoes);
    solicitou = true;
  }
  registrar('cadastro', 'Conta criada', u, primeiro ? 'Primeiro usuário: perfil Administrador' : solicitou ? 'Solicitou perfil Administrador' : '');
  res.status(201).json({ ok: true, perfil: u.perfil, solicitacaoAdmin: solicitou });
});

const falhas = new Map();
app.post('/api/login', (req, res) => {
  const b = req.body || {};
  const email = txt(b.email).toLowerCase(), senha = typeof b.senha === 'string' ? b.senha : '';
  const chave = req.ip + '|' + email, f = falhas.get(chave);
  if (f && f.n >= 5 && f.ate > Date.now()) return erro(res, 429, 'Muitas tentativas. Aguarde 1 minuto.');
  const u = usuarios.find(x => x.email === email);
  const ok = confere(senha, u ? u.senha : SENHA_FALSA) && u && u.ativo !== false;
  if (!ok) {
    falhas.set(chave, { n: (f && f.ate > Date.now() ? f.n : 0) + 1, ate: Date.now() + 60000 });
    registrar('login', 'Falha de login', null, email);
    return erro(res, 401, 'E-mail ou senha inválidos');
  }
  falhas.delete(chave);
  abrirSessao(res, u);
  registrar('login', 'Login', u);
  res.json(pub(u));
});

app.post('/api/logout', (req, res) => {
  if (req.user) {
    delete sessoes[req.sidKey];
    gravar('sessoes', sessoes);
    registrar('login', 'Logout', req.user);
  }
  res.clearCookie('simpe_sid', { path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', exigeLogin, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ...pub(req.user), favoritos: req.user.favoritos, recentes: req.user.recentes });
});

app.put('/api/me', exigeLogin, (req, res) => {
  const nome = txt(req.body && req.body.nome), dep = txt(req.body && req.body.departamento);
  if (!nome || !dep) return erro(res, 400, 'Informe nome e departamento');
  req.user.nome = nome; req.user.departamento = dep;
  gravar('usuarios', usuarios);
  registrar('conta', 'Perfil atualizado', req.user);
  res.json(pub(req.user));
});

app.post('/api/senha', exigeLogin, (req, res) => {
  const { atual, nova } = req.body || {};
  if (typeof atual !== 'string' || typeof nova !== 'string' || !confere(atual, req.user.senha)) return erro(res, 400, 'Senha atual incorreta');
  if (nova.length < 8) return erro(res, 400, 'A nova senha deve ter ao menos 8 caracteres');
  req.user.senha = hashSenha(nova);
  gravar('usuarios', usuarios);
  registrar('conta', 'Senha alterada', req.user);
  res.json({ ok: true });
});

// ───────────── Painéis ─────────────
function resumo(p, u) {
  const l = leituras[p.id];
  return {
    id: p.id, nome: p.nome, setor: p.setor, descricao: p.descricao, limites: p.limites,
    online: !!l && Date.now() - l.t < ONLINE_MS,
    alertas: alarmes.filter(a => a.painelId === p.id && a.estado !== 'Encerrado').length,
    acc: temAcesso(u, p.id), favorito: u.favoritos.includes(p.id),
    pendente: solicitacoes.some(s => s.usuarioId === u.id && s.tipo === 'acesso' && s.painelId === p.id && s.status === 'Pendente'),
    usuarios: isAdmin(u) ? usuarios.filter(x => x.ativo !== false && (isAdmin(x) || x.paineis.includes(p.id))).length : undefined
  };
}
const achaPainel = id => paineis.find(p => p.id === id);
function lerLimites(b, base) {
  const o = { ...base };
  Object.keys(PADRAO_LIMITES).forEach(k => { const v = Number(b && b[k]); if (b && b[k] !== undefined && v > 0 && isFinite(v)) o[k] = v; });
  return o;
}

app.get('/api/paineis', exigeLogin, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(paineis.map(p => resumo(p, req.user)));
});

app.post('/api/paineis', exigeAdmin, (req, res) => {
  const b = req.body || {}, id = txt(b.id, 20).toUpperCase(), nome = txt(b.nome), setor = txt(b.setor);
  if (!/^[A-Z0-9._-]{2,20}$/.test(id)) return erro(res, 400, 'Código inválido (use letras, números, ponto, hífen ou sublinhado)');
  if (!nome || !setor) return erro(res, 400, 'Informe nome e setor');
  if (achaPainel(id)) return erro(res, 409, 'Já existe um painel com esse código');
  const p = { id, nome, setor, descricao: txt(b.descricao, 400), limites: lerLimites(b.limites, PADRAO_LIMITES) };
  paineis.push(p);
  paineis.sort((a, c) => a.id.localeCompare(c.id));
  gravar('paineis', paineis);
  registrar('admin', `Painel criado: ${id} ${nome}`, req.user);
  res.status(201).json(resumo(p, req.user));
});

app.put('/api/paineis/:id', exigeAdmin, (req, res) => {
  const p = achaPainel(req.params.id);
  if (!p) return erro(res, 404, 'Painel não encontrado');
  const b = req.body || {};
  if (txt(b.nome)) p.nome = txt(b.nome);
  if (txt(b.setor)) p.setor = txt(b.setor);
  if (typeof b.descricao === 'string') p.descricao = txt(b.descricao, 400);
  if (b.limites) p.limites = lerLimites(b.limites, p.limites);
  gravar('paineis', paineis);
  registrar('admin', `Painel atualizado: ${p.id} ${p.nome}`, req.user);
  res.json(resumo(p, req.user));
});

app.delete('/api/paineis/:id', exigeAdmin, (req, res) => {
  const p = achaPainel(req.params.id);
  if (!p) return erro(res, 404, 'Painel não encontrado');
  paineis = paineis.filter(x => x !== p);
  usuarios.forEach(u => { u.paineis = u.paineis.filter(i => i !== p.id); u.favoritos = u.favoritos.filter(i => i !== p.id); u.recentes = u.recentes.filter(i => i !== p.id); });
  solicitacoes.forEach(s => { if (s.painelId === p.id && s.status === 'Pendente') { s.status = 'Recusada'; s.decididoEm = agora(); s.decididoPor = 'Sistema (painel removido)'; } });
  alarmes = alarmes.filter(a => a.painelId !== p.id);
  delete leituras[p.id];
  ['paineis', 'usuarios', 'solicitacoes', 'alarmes', 'leituras'].forEach(n => gravar(n, { paineis, usuarios, solicitacoes, alarmes, leituras }[n]));
  registrar('admin', `Painel removido: ${p.id} ${p.nome}`, req.user);
  res.json({ ok: true });
});

app.post('/api/paineis/:id/acesso', exigeLogin, (req, res) => {   // registra "acessado recentemente"
  const p = achaPainel(req.params.id);
  if (!p || !temAcesso(req.user, p.id)) return erro(res, 403, 'Sem acesso a este painel');
  req.user.recentes = [p.id, ...req.user.recentes.filter(i => i !== p.id)].slice(0, 5);
  gravar('usuarios', usuarios);
  res.json({ ok: true });
});

app.put('/api/favoritos/:id', exigeLogin, (req, res) => {
  if (!achaPainel(req.params.id)) return erro(res, 404, 'Painel não encontrado');
  const f = req.user.favoritos, i = f.indexOf(req.params.id);
  if (i >= 0) f.splice(i, 1); else f.push(req.params.id);
  gravar('usuarios', usuarios);
  res.json({ favorito: i < 0 });
});

// ───────────── Leituras e alarmes ─────────────
function verificar(p, sensor, violou, mensagem, severidade) {
  const aberto = alarmes.find(a => a.painelId === p.id && a.sensor === sensor && a.estado !== 'Encerrado');
  if (violou && !aberto) {
    alarmes.push({ id: uuid(), painelId: p.id, sensor, mensagem, severidade, estado: 'Ativo', criadoEm: agora() });
    gravar('alarmes', alarmes);
    registrar('alarme', `Alarme em ${p.id}: ${mensagem}`, null);
  } else if (!violou && aberto) {
    aberto.estado = 'Encerrado'; aberto.encerradoEm = agora();
    gravar('alarmes', alarmes);
    registrar('alarme', `Alarme encerrado em ${p.id}: ${aberto.mensagem}`, null);
  }
}

// Entrada de leituras (uso futuro pelo ESP32): header x-device-token
app.post('/api/leituras', (req, res) => {
  if (!tokenValido(req.get('x-device-token'))) return erro(res, 401, 'Token de dispositivo inválido');
  const b = req.body || {}, p = achaPainel(b.painel);
  if (!p) return erro(res, 404, 'Painel não encontrado');
  const v = {};
  for (const k of Object.keys(SENSORES)) if (b[k] !== undefined) { if (typeof b[k] !== 'number' || !isFinite(b[k])) return erro(res, 400, `"${k}" deve ser numérico`); v[k] = b[k]; }
  if (b.fumaca !== undefined) { if (typeof b.fumaca !== 'boolean') return erro(res, 400, '"fumaca" deve ser booleano'); v.fumaca = b.fumaca; }
  if (b.porta !== undefined) { if (b.porta !== 'aberta' && b.porta !== 'fechada') return erro(res, 400, '"porta" deve ser "aberta" ou "fechada"'); v.porta = b.porta; }
  const l = leituras[p.id] || (leituras[p.id] = { serie: [], valores: {} });
  l.t = Date.now(); l.ts = new Date(l.t).toISOString(); l.valores = { ...l.valores, ...v };
  l.serie.push({ t: l.t, corrente: v.corrente, temperatura: v.temperatura, umidade: v.umidade });
  if (l.serie.length > 120) l.serie.shift();
  gravarDepois('leituras', () => leituras);
  for (const k of Object.keys(SENSORES)) {
    if (typeof v[k] !== 'number') continue;
    const lim = p.limites[k];
    verificar(p, k, v[k] > lim, `${SENSORES[k][0]} acima de ${lim} ${SENSORES[k][1]}`, v[k] > lim * 1.1 ? 'Crítico' : 'Atenção');
  }
  if (typeof v.fumaca === 'boolean') verificar(p, 'fumaca', v.fumaca, 'Fumaça detectada', 'Crítico');
  res.json({ ok: true });
});

app.get('/api/paineis/:id/leituras', exigeLogin, (req, res) => {
  const p = achaPainel(req.params.id);
  if (!p) return erro(res, 404, 'Painel não encontrado');
  if (!temAcesso(req.user, p.id)) return erro(res, 403, 'Sem acesso a este painel');
  const l = leituras[p.id];
  res.set('Cache-Control', 'no-store');
  res.json({ online: !!l && Date.now() - l.t < ONLINE_MS, ultimo: l ? l.ts : null, valores: l ? l.valores : {}, serie: l ? l.serie.slice(-40) : [], limites: p.limites });
});

app.get('/api/alarmes', exigeLogin, (req, res) => {
  const id = txt(String(req.query.painel || ''), 20);
  if (id && !temAcesso(req.user, id)) return erro(res, 403, 'Sem acesso a este painel');
  const l = alarmes.filter(a => (id ? a.painelId === id : temAcesso(req.user, a.painelId)));
  res.set('Cache-Control', 'no-store');
  res.json([...l].reverse().slice(0, 200));
});

app.post('/api/alarmes/:id/reconhecer', exigeLogin, (req, res) => {
  const a = alarmes.find(x => x.id === req.params.id);
  if (!a) return erro(res, 404, 'Alarme não encontrado');
  if (!temAcesso(req.user, a.painelId)) return erro(res, 403, 'Sem acesso a este painel');
  if (a.estado !== 'Ativo') return erro(res, 409, 'Alarme já reconhecido ou encerrado');
  a.estado = 'Reconhecido'; a.reconhecidoPor = req.user.nome; a.reconhecidoEm = agora();
  gravar('alarmes', alarmes);
  registrar('alarme', `Alarme reconhecido em ${a.painelId}: ${a.mensagem}`, req.user);
  res.json(a);
});

// ───────────── Histórico ─────────────
const VISIVEL_OPERADOR = new Set(['comando', 'alarme']);
const celula = v => { let s = String(v == null ? '' : v); if (/^[=+\-@]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };

app.get('/api/historico', exigeLogin, (req, res) => {
  const q = k => (req.query[k] === undefined ? '' : String(req.query[k]).trim());
  let l = isAdmin(req.user) ? historico : historico.filter(h => VISIVEL_OPERADOR.has(h.tipo));
  if (q('de')) l = l.filter(h => h.data >= q('de'));
  if (q('ate')) l = l.filter(h => h.data <= q('ate'));
  if (q('usuario')) l = l.filter(h => h.usuario.toLowerCase().includes(q('usuario').toLowerCase()));
  if (q('tipo')) l = l.filter(h => h.tipo === q('tipo'));
  if (q('q')) l = l.filter(h => (h.acao + ' ' + h.detalhe).toLowerCase().includes(q('q').toLowerCase()));
  l = [...l].reverse();
  res.set('Cache-Control', 'no-store');
  if (q('formato') === 'csv') {
    const linhas = ['Data;Hora;Usuário;Tipo;Ação;Detalhe', ...l.map(h => [h.data, h.hora, h.usuario, h.tipo, h.acao, h.detalhe].map(celula).join(';'))];
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="historico.csv"' });
    return res.send('﻿' + linhas.join('\r\n'));
  }
  const limite = Math.min(Math.max(parseInt(q('limite'), 10) || 50, 1), 500), pagina = Math.max(parseInt(q('pagina'), 10) || 1, 1);
  res.json({ total: l.length, pagina, limite, itens: l.slice((pagina - 1) * limite, pagina * limite) });
});

// ───────────── Solicitações ─────────────
app.get('/api/solicitacoes', exigeLogin, (req, res) => {
  const l = isAdmin(req.user) ? solicitacoes : solicitacoes.filter(s => s.usuarioId === req.user.id);
  res.set('Cache-Control', 'no-store');
  res.json([...l].reverse());
});

app.post('/api/solicitacoes', exigeLogin, (req, res) => {
  const b = req.body || {}, u = req.user, just = txt(b.justificativa, 300);
  if (just.length < 3) return erro(res, 400, 'Informe a justificativa');
  let s;
  if (b.tipo === 'acesso') {
    const p = achaPainel(b.painelId);
    if (!p) return erro(res, 404, 'Painel não encontrado');
    if (temAcesso(u, p.id)) return erro(res, 409, 'Você já tem acesso a este painel');
    s = { tipo: 'acesso', painelId: p.id, titulo: `Acesso a ${p.id} ${p.nome}` };
  } else if (b.tipo === 'promocao') {
    if (isAdmin(u)) return erro(res, 409, 'Você já é Administrador');
    s = { tipo: 'promocao', painelId: null, titulo: 'Promoção a Administrador' };
  } else return erro(res, 400, 'Tipo de solicitação inválido');
  if (solicitacoes.some(x => x.usuarioId === u.id && x.tipo === s.tipo && x.painelId === s.painelId && x.status === 'Pendente')) return erro(res, 409, 'Já existe uma solicitação pendente');
  s = { id: uuid(), usuarioId: u.id, usuarioNome: u.nome, ...s, justificativa: just, status: 'Pendente', criadoEm: agora() };
  solicitacoes.push(s);
  gravar('solicitacoes', solicitacoes);
  registrar('solicitacao', `Solicitação enviada: ${s.titulo}`, u, just);
  res.status(201).json(s);
});

app.post('/api/solicitacoes/:id/decisao', exigeAdmin, (req, res) => {
  const s = solicitacoes.find(x => x.id === req.params.id), st = req.body && req.body.status;
  if (!s) return erro(res, 404, 'Solicitação não encontrada');
  if (s.status !== 'Pendente') return erro(res, 409, 'Solicitação já decidida');
  if (st !== 'Aprovada' && st !== 'Recusada') return erro(res, 400, 'Status deve ser "Aprovada" ou "Recusada"');
  s.status = st; s.decididoEm = agora(); s.decididoPor = req.user.nome;
  if (st === 'Aprovada') {
    const u = usuarios.find(x => x.id === s.usuarioId);
    if (u) {
      if (s.tipo === 'acesso' && achaPainel(s.painelId) && !u.paineis.includes(s.painelId)) u.paineis.push(s.painelId);
      if (s.tipo === 'promocao') u.perfil = 'Administrador';
      gravar('usuarios', usuarios);
    }
  }
  gravar('solicitacoes', solicitacoes);
  registrar('admin', `Solicitação ${st.toLowerCase()}: ${s.titulo}`, req.user, `Usuário: ${s.usuarioNome}`);
  res.json(s);
});

// ───────────── Administração de usuários ─────────────
app.get('/api/usuarios', exigeAdmin, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json(usuarios.map(pub));
});

app.patch('/api/usuarios/:id', exigeAdmin, (req, res) => {
  const u = usuarios.find(x => x.id === req.params.id), b = req.body || {};
  if (!u) return erro(res, 404, 'Usuário não encontrado');
  const perfil = b.perfil === undefined ? u.perfil : b.perfil;
  const ativo = typeof b.ativo === 'boolean' ? b.ativo : u.ativo !== false;
  if (perfil !== 'Administrador' && perfil !== 'Operador') return erro(res, 400, 'Perfil inválido');
  if (isAdmin(u) && u.ativo !== false && (perfil !== 'Administrador' || !ativo) && !usuarios.some(x => x !== u && isAdmin(x) && x.ativo !== false))
    return erro(res, 409, 'Deve existir ao menos um Administrador ativo');
  const antes = `${u.perfil}, ${u.ativo !== false ? 'ativo' : 'inativo'}`;
  u.perfil = perfil; u.ativo = ativo;
  if (txt(b.nome)) u.nome = txt(b.nome);
  if (txt(b.departamento)) u.departamento = txt(b.departamento);
  if (!ativo) encerrarSessoes(u.id);
  gravar('usuarios', usuarios);
  registrar('admin', `Usuário atualizado: ${u.nome}`, req.user, `${antes} → ${u.perfil}, ${ativo ? 'ativo' : 'inativo'}`);
  res.json(pub(u));
});

app.put('/api/usuarios/:id/permissoes', exigeAdmin, (req, res) => {
  const u = usuarios.find(x => x.id === req.params.id), b = req.body || {};
  if (!u) return erro(res, 404, 'Usuário não encontrado');
  if (!Array.isArray(b.paineis) || typeof b.controle !== 'boolean') return erro(res, 400, 'Envie "paineis" (lista) e "controle" (booleano)');
  u.paineis = [...new Set(b.paineis.filter(id => achaPainel(id)))];
  u.controle = b.controle;
  gravar('usuarios', usuarios);
  registrar('admin', `Permissões atualizadas: ${u.nome}`, req.user, `Painéis: ${u.paineis.join(', ') || 'nenhum'} · Controle: ${u.controle ? 'sim' : 'não'}`);
  res.json(pub(u));
});

// ───────────── Notificações (derivadas dos dados reais) ─────────────
app.get('/api/notificacoes', exigeLogin, (req, res) => {
  const u = req.user, n = [];
  solicitacoes.filter(s => s.usuarioId === u.id && s.status !== 'Pendente' && s.decididoEm).slice(-5).reverse()
    .forEach(s => n.push({ titulo: `Solicitação ${s.status.toLowerCase()}`, texto: s.titulo, quando: `${s.decididoEm.data} ${s.decididoEm.hora.slice(0, 5)}` }));
  if (isAdmin(u)) {
    const pend = solicitacoes.filter(s => s.status === 'Pendente').length;
    if (pend) n.push({ titulo: `${pend} solicitaç${pend > 1 ? 'ões pendentes' : 'ão pendente'}`, texto: 'Aguardando decisão', link: 'admin.html' });
  }
  const ativos = alarmes.filter(a => a.estado === 'Ativo' && temAcesso(u, a.painelId)).length;
  if (ativos) n.push({ titulo: `${ativos} alarme${ativos > 1 ? 's ativos' : ' ativo'}`, texto: 'Sem reconhecimento', link: 'catalogo.html' });
  res.set('Cache-Control', 'no-store');
  res.json(n);
});

// ───────────── Erros ─────────────
app.use('/api', (req, res) => erro(res, 404, 'Rota não encontrada'));
app.use((req, res, next) => {        // qualquer outro caminho sem extensão volta para a raiz
  if (req.method === 'GET' && !path.extname(req.path)) return res.redirect('/');
  next();
});
app.use((err, req, res, next) => {   // JSON malformado etc.
  if (res.headersSent) return next(err);
  erro(res, err.status && err.status < 500 ? err.status : 500, err.status && err.status < 500 ? 'Requisição inválida' : 'Erro interno do servidor');
});

function encerrar() {
  Object.keys(adiados).forEach(n => clearTimeout(adiados[n]));
  try { gravar('leituras', leituras); } catch (e) { /* ignora */ }
  process.exit(0);
}
process.on('SIGINT', encerrar);
process.on('SIGTERM', encerrar);

app.listen(PORT, HOST, () => {
  console.log(`SIMPE em http://localhost:${PORT} (escutando em ${HOST}:${PORT})`);
  console.log(`Dados em: ${DIR}`);
  if (!usuarios.length) console.log('Nenhum usuário cadastrado: o primeiro cadastro em /cadastro.html será o Administrador.');
  console.log(`Token de dispositivo (POST /api/leituras): ${TOKEN_DISPOSITIVO}`);
});
