/*
 * SIMPE - Controle de 2 ventoinhas via ESP32-WROOM-32 + módulo relé 5V
 *
 * Relé com LÓGICA INVERTIDA:
 *   LOW  = relé acionado  = ventoinha LIGADA
 *   HIGH = relé em repouso = ventoinha DESLIGADA
 *
 * Ligações:
 *   IN1 -> GPIO 25 -> Ventoinha 1
 *   IN2 -> GPIO 26 -> Ventoinha 2
 *   GPIO 27 e GPIO 33: nada conectado (mantidos em HIGH = desligados)
 *
 * O ESP32 consulta GET http://IP_DO_COMPUTADOR:3000/api/estado a cada 500 ms.
 */

#include <WiFi.h>
#include <HTTPClient.h>

// ╔══════════════════════════════════════════════════════════════╗
// ║  >>>  PREENCHA OS 3 CAMPOS ABAIXO ANTES DE ENVIAR  <<<       ║
// ╚══════════════════════════════════════════════════════════════╝
const char* WIFI_SSID     = "COLOQUE_O_NOME_DA_REDE_WIFI";   // 1) SSID (nome da rede, 2.4 GHz)
const char* WIFI_SENHA    = "COLOQUE_A_SENHA_DO_WIFI";       // 2) Senha do Wi-Fi
const char* IP_DO_COMPUTADOR = "192.168.0.100";              // 3) IPv4 do computador que roda o server.js
// ════════════════════════════════════════════════════════════════

const int  PORTA_SERVIDOR = 3000;
const unsigned long INTERVALO_MS = 500;

// Pinos do relé
const int PIN_VENTOINHA_1 = 25;  // IN1
const int PIN_VENTOINHA_2 = 26;  // IN2
const int PIN_RESERVA_1   = 27;  // sem uso (mantido desligado)
const int PIN_RESERVA_2   = 33;  // sem uso (mantido desligado)

// Lógica invertida do módulo relé
const int RELE_LIGA    = LOW;
const int RELE_DESLIGA = HIGH;

unsigned long ultimaConsulta = 0;

void iniciaPinoDesligado(int pino) {
  digitalWrite(pino, RELE_DESLIGA);  // define o nível ANTES de virar saída (evita pulso no relé)
  pinMode(pino, OUTPUT);
  digitalWrite(pino, RELE_DESLIGA);
}

void conectaWiFi() {
  Serial.printf("Conectando ao Wi-Fi \"%s\"", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_SENHA);
  unsigned long inicio = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - inicio < 20000) {
    delay(300);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("\nConectado! IP do ESP32: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nFalha ao conectar. Vai tentar de novo...");
  }
}

void consultaEstado() {
  String url = String("http://") + IP_DO_COMPUTADOR + ":" + PORTA_SERVIDOR + "/api/estado";

  WiFiClient cliente;
  HTTPClient http;
  http.setConnectTimeout(1000);
  http.setTimeout(1000);

  if (!http.begin(cliente, url)) {
    Serial.println("Erro ao iniciar HTTP");
    return;
  }

  int codigo = http.GET();
  if (codigo == HTTP_CODE_OK) {
    String corpo = http.getString();   // ex.: {"ventoinha1":true,"ventoinha2":false}
    bool v1 = corpo.indexOf("\"ventoinha1\":true") >= 0;
    bool v2 = corpo.indexOf("\"ventoinha2\":true") >= 0;

    digitalWrite(PIN_VENTOINHA_1, v1 ? RELE_LIGA : RELE_DESLIGA);
    digitalWrite(PIN_VENTOINHA_2, v2 ? RELE_LIGA : RELE_DESLIGA);

    static int ultimo = -1;
    int atual = (v1 ? 1 : 0) | (v2 ? 2 : 0);
    if (atual != ultimo) {  // só imprime quando muda
      Serial.printf("Ventoinha 1: %s | Ventoinha 2: %s\n",
                    v1 ? "LIGADA" : "DESLIGADA", v2 ? "LIGADA" : "DESLIGADA");
      ultimo = atual;
    }
  } else {
    // Mantém o último estado dos relés enquanto o servidor não responde
    Serial.printf("Falha na consulta (código %d)\n", codigo);
  }
  http.end();
}

void setup() {
  Serial.begin(115200);
  delay(200);

  // Todos os pinos do relé começam em HIGH (desligados)
  iniciaPinoDesligado(PIN_VENTOINHA_1);
  iniciaPinoDesligado(PIN_VENTOINHA_2);
  iniciaPinoDesligado(PIN_RESERVA_1);
  iniciaPinoDesligado(PIN_RESERVA_2);

  conectaWiFi();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    conectaWiFi();
    return;
  }

  unsigned long agora = millis();
  if (agora - ultimaConsulta >= INTERVALO_MS) {
    ultimaConsulta = agora;
    consultaEstado();
  }
}
